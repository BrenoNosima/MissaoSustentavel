# Missão Sustentável - Projeto Componentizado

Este projeto foi refatorado seguindo as melhores práticas de componentização em Vue.js.

## Estrutura do Projeto

```
src/
├── components/
│   ├── Navbar.vue           # Componente de navegação
│   ├── HeroSection.vue      # Seção hero da página inicial
│   ├── FeaturesSection.vue  # Seção de funcionalidades
│   ├── StatsSection.vue     # Seção de estatísticas
│   └── ChallengeCard.vue    # Card individual de desafio
├── views/
│   ├── Home.vue             # Página inicial
│   ├── Challenges.vue       # Página de desafios
│   ├── About.vue            # Página sobre
│   └── Resources.vue        # Página de recursos
├── App.vue                  # Componente principal
└── main.js                  # Arquivo de entrada
```

## Melhorias Implementadas

### 1. Separação de Responsabilidades
- **Componentes reutilizáveis**: Navbar, HeroSection, FeaturesSection, StatsSection, ChallengeCard
- **Views específicas**: Home, Challenges, About, Resources
- **Componente principal**: App.vue gerencia apenas a navegação e layout geral

### 2. Comunicação entre Componentes
- Uso de **props** para passar dados dos pais para filhos
- Uso de **eventos customizados** ($emit) para comunicação de filhos para pais
- Navegação centralizada no componente App.vue

### 3. Organização de Código
- Separação clara entre lógica de apresentação (components) e lógica de página (views)
- Estilos scoped para evitar conflitos de CSS
- Imports organizados e padronizados

### 4. Boas Práticas Aplicadas
- **Single Responsibility Principle**: Cada componente tem uma responsabilidade específica
- **DRY (Don't Repeat Yourself)**: Componentes reutilizáveis evitam duplicação de código
- **Nomenclatura consistente**: PascalCase para componentes, camelCase para props e métodos
- **Estrutura de pastas organizada**: Separação clara entre components e views

## Como Executar

1. Instale as dependências:
```bash
npm install
```

2. Execute o projeto em modo de desenvolvimento:
```bash
npm run serve
```

3. Para build de produção:
```bash
npm run build
```

## Componentes Criados

### Navbar.vue
- Componente de navegação reutilizável
- Recebe `currentPage` como prop
- Emite evento `navigate` para mudança de página

### HeroSection.vue
- Seção hero da página inicial
- Emite evento `navigate` para navegação

### FeaturesSection.vue
- Seção que explica como funciona a plataforma
- Componente puramente apresentacional

### StatsSection.vue
- Seção de estatísticas da plataforma
- Componente puramente apresentacional

### ChallengeCard.vue
- Card reutilizável para exibir desafios
- Recebe `challenge` como prop
- Emite evento `view-challenge` para visualizar detalhes

### Views (Home, Challenges, About, Resources)
- Componentes de página que organizam outros componentes
- Gerenciam estado específico da página
- Implementam lógica de negócio específica

## Benefícios da Componentização

1. **Manutenibilidade**: Código mais fácil de manter e atualizar
2. **Reutilização**: Componentes podem ser reutilizados em diferentes contextos
3. **Testabilidade**: Componentes menores são mais fáceis de testar
4. **Colaboração**: Diferentes desenvolvedores podem trabalhar em componentes diferentes
5. **Performance**: Possibilidade de otimizações específicas por componente

