<template>
  <div class="container py-5">
    <div class="row">
      <div class="col-lg-8 mx-auto">
        <h1 class="fw-bold mb-4">Recursos Educacionais</h1>
        <p class="lead">
          Aqui você encontra materiais complementares, artigos e links úteis para aprofundar seus conhecimentos em sustentabilidade.
        </p>
        
        <h3 class="fw-bold mt-5 mb-3">Artigos Recomendados</h3>
        <ul>
          <li><a href="#" target="_blank">A Importância da Reciclagem no Dia a Dia</a></li>
          <li><a href="#" target="_blank">Dicas para Economizar Água em Casa</a></li>
          <li><a href="#" target="_blank">Compostagem: Transformando Lixo em Adubo</a></li>
        </ul>

        <h3 class="fw-bold mt-5 mb-3">Vídeos e Documentários</h3>
        <ul>
          <li><a href="#" target="_blank">Nosso Planeta (Netflix)</a></li>
          <li><a href="#" target="_blank">Uma Verdade Inconveniente (Al Gore)</a></li>
        </ul>

        <h3 class="fw-bold mt-5 mb-3">Organizações Parceiras</h3>
        <ul>
          <li><a href="#" target="_blank">WWF Brasil</a></li>
          <li><a href="#" target="_blank">Greenpeace Brasil</a></li>
          <li><a href="#" target="_blank">Instituto Akatu</a></li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'ResourcesPage'
}
</script>


