<template>
  <div class="container py-5">
    <div class="row">
      <div class="col-lg-8 mx-auto">
        <h1 class="fw-bold mb-4">Sobre o Projeto</h1>
        <p class="lead">
          A Missão Sustentável é uma plataforma educacional que conecta estudantes a ações práticas de sustentabilidade, 
          promovendo o aprendizado através da experiência e do engajamento comunitário.
        </p>
        
        <h3 class="fw-bold mt-5 mb-3">Nossa Missão</h3>
        <p>
          Capacitar jovens para se tornarem agentes de mudança em suas comunidades, desenvolvendo consciência ambiental 
          e habilidades práticas para enfrentar os desafios da sustentabilidade.
        </p>
        
        <h3 class="fw-bold mt-5 mb-3">Como Surgiu</h3>
        <p>
          O projeto nasceu da necessidade de tornar a educação ambiental mais prática e engajante, 
          conectando o aprendizado teórico com ações concretas que geram impacto real na comunidade.
        </p>
        
        <h3 class="fw-bold mt-5 mb-3">Metodologia</h3>
        <p>
          Utilizamos uma abordagem baseada em desafios práticos, onde os estudantes aprendem fazendo. 
          Cada desafio é cuidadosamente elaborado para ser:
        </p>
        <ul>
          <li><strong>Realizável:</strong> Adequado para adolescentes com nível médio de dificuldade</li>
          <li><strong>Impactante:</strong> Gera mudanças reais na comunidade</li>
          <li><strong>Educacional:</strong> Ensina sobre sustentabilidade de forma prática</li>
          <li><strong>Mensurável:</strong> Permite acompanhar o impacto gerado</li>
        </ul>

        <h3 class="fw-bold mt-5 mb-3">Nossa Equipe</h3>
        <p>
          Somos um grupo apaixonado por sustentabilidade e educação, dedicados a criar um futuro mais verde e consciente.
        </p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'AboutPage'
}
</script>


