<template>
  <section class="bg-green-light py-5">
    <div class="container">
      <div class="row text-center g-4">
        <div class="col-md-3">
          <h3 class="fw-bold text-green-custom display-6">52</h3>
          <p class="mb-0">Desafios Semanais</p>
        </div>
        <div class="col-md-3">
          <h3 class="fw-bold text-green-custom display-6">15%</h3>
          <p class="mb-0">Bonificação Máxima</p>
        </div>
        <div class="col-md-3">
          <h3 class="fw-bold text-green-custom display-6">100+</h3>
          <p class="mb-0">Escolas Participantes</p>
        </div>
        <div class="col-md-3">
          <h3 class="fw-bold text-green-custom display-6">5000+</h3>
          <p class="mb-0">Estudantes Engajados</p>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'StatsSection'
}
</script>

<style scoped>
.bg-green-light {
  background-color: #d4edda; /* Um verde claro para o fundo */
}

.text-green-custom {
  color: #28a745;
}
</style>


